package com.heigvd.gen.chat.Network;

/**
 * Created by Antoine on 14.05.2016.
 */
public class Configuration {
    public static final String url = "http://loki.cpfk.net:9999/api/";
}
